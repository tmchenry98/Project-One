#include <iostream>
#include <cstring>
#include <iomanip> //for the set percision
#pragma warning(disable : 4996) //getting this warning trying to use localtime 

using namespace std;

//Global variables
int hour; // keeps hours
int minutes;// keeps minutes
int seconds;// keeps seconds
int menuSelect;// keep track of the users selection 
int hourAdd;// to keep track of hours added
int minAdd;// to keep track of mins added
int secondAdd;// to keep track of seconds added

// void Menu() is here just to read ut the menu options
void Menu() {
	cout << "Please choose a menu option" << endl << endl;
	cout << "1: Add Hours." << endl;
	cout << "2: Add Minutes." << endl;
	cout << "3: Add Seconds." << endl;
	cout << "4: Quit program." << endl;
}

void AdditionalHours(int hoursAdded) { hourAdd += hoursAdded; };

void AdditionalMinutes(int minsAdded) {
	//local variables to handle excess mins
	int remainderMins = 0;
	int extraHours = 0;

	//handles excess minutes if the amount added is more than 60 then calls to add to the additional hours function
	if (minsAdded >= 60) {
		extraHours = (minsAdded / 60);
		minsAdded = (minsAdded % 60);
		AdditionalHours(extraHours);
		minAdd += minsAdded;
	}
	else { minAdd += minsAdded; };

};

//same setup as the one above
void AdditionalSeconds(int secondsAdded) {
	int remainderSecs = 0;
	int extraMins = 0;

	if (secondsAdded >= 60) {
		extraMins = (secondsAdded / 60);
		secondsAdded = (secondsAdded % 60);
		AdditionalMinutes(extraMins);
		secondAdd += secondsAdded;
	}
	else { secondAdd += secondsAdded; };

};

void GetTime() {
	time_t ttime = time(0);
	tm* local_time = localtime(&ttime);

	//local variables to help handle excess time
	int tempHour = 0;
	int tempMins = 0;

	hour = local_time->tm_hour + hourAdd;
	//followed a similar method as the time added functions to handle excess time 
	minutes = local_time->tm_min + minAdd;
	if (minutes >= 60) {
		tempHour = (minutes / 60);
		hour = local_time->tm_hour + hourAdd + tempHour;
		minutes = (minutes % 60);

	};

	seconds = local_time->tm_sec + secondAdd;
	if (seconds >= 60) {
		tempMins = (minutes / 60);
		minutes = local_time->tm_min + minAdd + tempMins;
		seconds = (seconds % 60);

	};
}


//This function takes in the 24 time and handles the conversion from 24 to 12 hours
void TwelveHrClock(int& hour, int& minutes, int& seconds) {

	//local variables 
	bool isPM = false;
	string amOrPm = "AM";
	int hour12 = hour;// using this to separate the hour12 out from the hour

	if (hour >= 12) {
		isPM = true;
	}

	if (isPM == true) {
		amOrPm = "PM";
	}
	
		//catches over 12
	if (hour >= 24) {
		hour12 % 24;
	}
	// catches midnight
	if (hour == 0) {
		hour12 = 12;
	}
	// catches noon
	if (hour12 >= 13) {
		hour12 = hour12 % 12;
	}

	//final output
	cout << hour12 << ":" << minutes << ":" << seconds << " " << amOrPm << endl << endl;

}

void TwentyFourHrClock(int& hour, int& minutes, int& seconds) {
	cout << fixed << setprecision(2); //<< setfill('0');
	cout << hour << ":" << minutes << ":" << seconds << " || ";
	TwelveHrClock(hour, minutes, seconds);
}

void Menuselction(int menuSelect) {
	//local variables
	int hourInput = 0, minInput, secInput;

	if (menuSelect == 1) {
		cout << "Please input the amount of hours you wish to add: " << endl;
		cin >> hourInput;
		AdditionalHours(hourInput);
		cout << endl;
	}
	else if (menuSelect == 2) {
		cout << "Please input the amount of minutes you wish to add: " << endl;
		cin >> minInput;
		AdditionalMinutes(minInput);
		cout << endl;
	}
	else if (menuSelect == 3) {
		cout << "Please input the amount of seconds you wish to add: " << endl;
		cin >> secInput;
		AdditionalSeconds(secInput);
		cout << endl;
	}
	else if (menuSelect == 4) {
		cout << "Thanks for choosing Chada Tech's Clock" << endl;
	}
	else {
		cout << "Please only choose between the numbers 1-4" << endl << endl;
		cin.clear();
		cin.ignore(100, '\n');
	};


};

int main() {
	hourAdd = 0;
	minAdd = 0;
	secondAdd = 0;
	cout << fixed << setprecision(2);
	cout << "Hello welcome to the clock app" << endl << endl;

	do {
		cout << "The current time is set to" << endl;
		GetTime();

		TwentyFourHrClock(hour, minutes, seconds);

		Menu();

		//get users menuselecetion option
		cin >> menuSelect;

		Menuselction(menuSelect);

	} while (menuSelect != 4);

}